//
//  PersonCell.swift
//  Project10
//
//  Created by TwoStraws on 17/08/2016.
//  Copyright © 2016 Paul Hudson. All rights reserved.
//

import UIKit

class PersonCell: UICollectionViewCell {
	@IBOutlet var imageView: UIImageView!
	@IBOutlet var name: UILabel!
}
