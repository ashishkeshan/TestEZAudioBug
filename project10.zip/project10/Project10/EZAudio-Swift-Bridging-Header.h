//
//  EZAudio-Swift-Bridging-Header.h
//  EZAudio-Swift
//
//  Created by Syed Haris Ali on 7/9/15.
//  Copyright (c) 2015 Syed Haris Ali. All rights reserved.
//

#ifndef EZAudio_Swift_EZAudio_Swift_Bridging_Header_h
#define EZAudio_Swift_EZAudio_Swift_Bridging_Header_h

#import <EZAudio.h>

#endif
